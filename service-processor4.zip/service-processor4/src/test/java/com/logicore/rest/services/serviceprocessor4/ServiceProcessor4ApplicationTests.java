package com.logicore.rest.services.serviceprocessor4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProcessor4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
