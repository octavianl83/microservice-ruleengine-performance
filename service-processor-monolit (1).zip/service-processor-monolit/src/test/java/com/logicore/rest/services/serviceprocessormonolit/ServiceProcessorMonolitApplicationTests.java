package com.logicore.rest.services.serviceprocessormonolit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProcessorMonolitApplicationTests {

	@Test
	void contextLoads() {
	}

}
