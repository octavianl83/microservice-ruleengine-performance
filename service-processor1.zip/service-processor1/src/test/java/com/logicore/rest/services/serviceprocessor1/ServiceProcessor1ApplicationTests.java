package com.logicore.rest.services.serviceprocessor1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProcessor1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
