package com.logicore.rest.services.serviceprocessor1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceProcessor1Application {

	public static void main(String[] args) {
		SpringApplication.run(ServiceProcessor1Application.class, args);
	}

}
