package com.logicore.rest.services.serviceprocessor2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceProcessor2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
